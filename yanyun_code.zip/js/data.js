//头部导航
//var arrNav = ["首页","产品与服务","客户案例","新闻中心","关于我们"]
$(document).ready(function() {
	jQuery.support.cors = true;
	var url = "js/header.json";
	$.ajax({
		type: "GET",
		contentType:'text/html;charset=UTF-8',
		url: url,
		dataType: "json",
		success: function(data) {
			data.data.logo_header.forEach(function (i) {
				var html = "<a href='/'>"
				html+="<img id="+ i.id +" src="+ i.img +" />";
				html+="</a>";
				$('.nav-logo').append(html);
			});
			data.data.navigation_header.forEach(function (a) {
				var html = "<li>";
				html += "<a href="+ a.url +">" + a.title + "</a>";
				html += "</li>";
				$('.categories-ul').append(html);
			});
			data.data.contact_header.forEach(function(i){
				var html = "<img src='http://www.cloudcy.cn/" + i.img +"'>";
					html += "<p>0311-66600076</p>";
					$('.nav-tel').append(html);
			})
		}
	});
	$.ajaxSetup({cache: false }); 
});


//底部二维码
var arr = ['联系我们','电话：0311-66600076','邮箱：yanyunkeji@yanyunkeji.com','地址：河北省石家庄市裕华西路15号万象天成商务广场c座15层']
$(document).ready(function() {
	jQuery.support.cors = true;
	$.ajax({
		type: "GET",
		contentType:'text/html;charset=UTF-8',
		url: "http://www.cloudcy.cn/page/pageContent/footer",
		dataType: "json",
		success: function(data){
			data.data.QR_code_footer.forEach(function (i) {
				var html = "<li><img src='http://www.cloudcy.cn/" + i.img + "'></li>"
//				$('.footer-ol').append(html);
			});
			arr.forEach(function(f){
				var html1 = "<li>"+f+"</li>";
				$('#footer .footer-ul ul').append(html1);
			});
			
			$('#footer').append("<p>河北研云科技有限公司 冀ICP备17032151号-1</p>");
		}
	});
	$.ajaxSetup({cache: false });
});
//乘云大数据
$(document).ready(function(){
	$(document).on("mouseover","#home-cloud .bigData .data-server-ul ul li",function(){
//	$("#home-cloud .bigData .data-server-ul ul li").mouseover(function(){
		$(this).addClass("active").siblings().removeClass("active");
	});
	$(document).on("mouseout","#home-cloud .bigData .data-server-ul ul li",function(){
	//$("#home-cloud .bigData .data-server-ul ul li").mouseout(function(){
		$(this).removeClass("active");
	});
	
});		
