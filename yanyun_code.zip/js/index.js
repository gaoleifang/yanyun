//乘云 云上服务
function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if(r != null) return unescape(r[2]);
	return null;
}

$(document).ready(function () {
	$('.ula .cloud-server-ul').on('mouseover', '.cloud-server-li', function() {
		console.log($('.cloud-server-li1')[0])
		var i = $(this).index();
		$('.cloud-server-li1')[i].style.display = 'none';
		$('.cloud-server-li2')[i].style.display = 'block';
		$('.cloud-server-li1')[0].style.display = 'block';
		$('.cloud-server-li2')[0].style.display = 'none';
		if (i == 0) {
			$('.cloud-server-li1')[0].style.display = 'none';
			$('.cloud-server-li2')[0].style.display = 'block';
		}
	});
	$('.ula .cloud-server-ul').on('mouseout', '.cloud-server-li', function() {
		var i = $(this).index();
		$('.cloud-server-li1')[i].style.display = 'block';
		$('.cloud-server-li2')[i].style.display = 'none';
		$('.cloud-server-li1')[0].style.display = 'none';
		$('.cloud-server-li2')[0].style.display = 'block';
		if (i == 0) {
			$('.cloud-server-li1')[0].style.display = 'none';
			$('.cloud-server-li2')[0].style.display = 'block';
		}
	});
	
	$('.ulb .cloud-server-ul').on('mouseover', '.cloud-server-li', function() {
		console.log($(this)[0])
		var i = $(this).index();
		$('.ulb .cloud-server-li1')[i].style.display = 'none';
		$('.ulb .cloud-server-li2')[i].style.display = 'block';
		$('.ulb .cloud-server-li1')[0].style.display = 'block';
		$('.ulb .cloud-server-li2')[0].style.display = 'none';
		if (i == 0) {
			$('.ulb .cloud-server-li1')[0].style.display = 'none';
			$('.ulb .cloud-server-li2')[0].style.display = 'block';
		}
	});
	$('.ulb .cloud-server-ul').on('mouseout', '.cloud-server-li', function() {
		var i = $(this).index();
		$('.ulb .cloud-server-li1')[i].style.display = 'block';
		$('.ulb .cloud-server-li2')[i].style.display = 'none';
		$('.ulb .cloud-server-li1')[0].style.display = 'none';
		$('.ulb .cloud-server-li2')[0].style.display = 'block';
		if (i == 0) {
			$('.ulb .cloud-server-li1')[0].style.display = 'none';
			$('.ulb .cloud-server-li2')[0].style.display = 'block';
		}
	});
})


//回到顶部
$(document).ready(function() {
	var st = document.body.scrollTop;
	if(st > 0) {
		$('#gotop').css('display', 'block');
	} else {
		$('#gotop').css('display', 'none');
	}
	$(document).scroll(function() {
		var st = document.body.scrollTop;
		if(st > 0) {
			$('#gotop').css('display', 'block');
		} else {
			$('#gotop').css('display', 'none');
		}
	})
	$("#gotop").click(function() {
		var speed = 200; //滑动的速度
		$('body,html').animate({
			scrollTop: 0
		}, speed);
		return false;
	});
});
//大数据导航改变颜色
$(document).ready(function() {
	$('.bd_head_bottom ul li').hover(function() {
		$(this).addClass('cur');
	}, function() {
		$(this).removeClass('cur');
	})
});
//云计算点击移动到相应位置
	$(document).on("click","#p1",function(){
		$("html, body").animate({
            scrollTop: $("#pro-overview").offset().top }, {duration: 500,easing: "swing"});
        return false;
	})
	$(document).on("click","#p2",function(){
		$("html, body").animate({
            scrollTop: $("#pro-feature").offset().top }, {duration: 500,easing: "swing"});
        return false;
	})
	$(document).on("click","#p3",function(){
		$("html, body").animate({
            scrollTop: $("#pro-size").offset().top }, {duration: 500,easing: "swing"});
        return false;
	})
//	$('#p1').click(function () {
//		alert(1);
//		$("html, body").animate({
//          scrollTop: $("#pro-overview").offset().top }, {duration: 500,easing: "swing"});
//      return false;
//	});
//解决方案
	$(document).on("click","#a1",function(){
		$("html, body").animate({
            scrollTop: $("#bra").offset().top }, {duration: 480,easing: "swing"});
        return false;
	})
	$(document).on("click","#a2",function(){
		$("html, body").animate({
            scrollTop: $("#re").offset().top }, {duration: 480,easing: "swing"});
        return false;
	})
	$(document).on("click","#a3",function(){
		$("html, body").animate({
            scrollTop: $("#hot_plan").offset().top }, {duration: 480,easing: "swing"});
        return false;
	})
	$(document).on("click","#a4",function(){
		$("html, body").animate({
            scrollTop: $("#al").offset().top }, {duration: 480,easing: "swing"});
        return false;
	})
	$(document).on("click","#a5",function(){
		$("html, body").animate({
            scrollTop: $("#su").offset().top }, {duration: 500,easing: "swing"});
        return false;
	})
//点击导航显示
$(".nav-menu p").on('click', function () {
	$('.c-nav-categories-detail').toggle(100);
})
